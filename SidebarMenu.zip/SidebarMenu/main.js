document.addEventListener('DOMContentLoaded', function() {


    // Gran Menu Items
    const items = document.querySelectorAll('.menu-item a');

    // Listen for menu item click
    items.forEach(function(item) {
        item.addEventListener('click', function() {
            removeActives();
            // Add active class to selected item
            item.classList.add('active');

        })
    });

    function removeActives() {
        items.forEach(function(item) {
            item.classList.remove('active');
        })
    }

});